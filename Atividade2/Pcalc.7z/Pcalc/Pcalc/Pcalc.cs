﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        
        public Form1()
        {
            InitializeComponent();
        }

        private void txtNum3_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtNum2_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtNum1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void btnMin_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtNum3.Text = resultado.ToString();
        }

        private void btnMult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtNum3.Text = resultado.ToString();
        }

        private void btnDiv_Click(object sender, EventArgs e)
        {
            if (numero1 == 0)
            {
                MessageBox.Show("Valor inválido, informe um número maior que 0!!");
            } else if (numero2 == 0)
            {
                MessageBox.Show("Valor inválido, informe um número maior que 0!!");
            } else
            {
                resultado = numero1 / numero2;
                txtNum3.Text = resultado.ToString();
            }
            
        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("Número Invalido... Digite um Número! ");
                txtNum2.Focus();
            }
        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("Número Invalido... Digite um Número! ");
                txtNum2.Focus();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = "";
            txtNum1.Text = "";
            txtNum2.Text = "";
            txtNum2.Text = "";
            txtNum3.Text = "";

        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtNum1_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtNum3.Text = resultado.ToString();
        }
    }
}
